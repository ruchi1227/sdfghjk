package com.bikeservice.company.dtos;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class AddressDto {
	private int houseNumber;
	private String streetName;
	private String landmark;
	private String city;
	private String state;
	private long pincode;
}
