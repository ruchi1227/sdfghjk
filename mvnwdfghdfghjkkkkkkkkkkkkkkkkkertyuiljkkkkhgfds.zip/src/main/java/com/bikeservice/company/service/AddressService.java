package com.bikeservice.company.service;

public interface AddressService {

	
}
