package com.bikeservice.company.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.bikeservice.company.models.Bike;

public interface BikeRepo extends JpaRepository<Bike, Integer> {

}
