package com.bikeservice.company.service.impl;

import java.sql.Timestamp;

import com.bikeservice.company.dtos.BikeDto;
import com.bikeservice.company.models.Bike;
import com.bikeservice.company.service.BikeService;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;


public class BikeServiceImpl implements BikeService{

	@Override
	public Bike createBike(BikeDto bikeDto) {
		// TODO Auto-generated method stub
		Bike newBike=new Bike();
		newBike.setBikeMake(bikeDto.getBikeMake());
		newBike.setBikeModelName(bikeDto.getBikeModelName());
		newBike.setBikeRegistrationNumber(bikeDto.getBikeRegistrationNumber());
		newBike.setBikeChassisNumber(bikeDto.getBikeChassisNumber());
		newBike.setBikeKnownIssues(bikeDto.getBikeKnownIssues());
		newBike.setBikeServiceCost(calculateBikeServiceCost(bikeDto.getBikeKnownIssues()));
		LocalDateTime nowTime=new LocalDateTime()
		newBike.setBikeGivenDate(Timestamp.valueOf(timeToString(new LocalDateTime())));
		newBike.s
		return null;
	}
	public int calculateBikeServiceCost(String issue) {
		return 100+(issue.length())*10;
	}
	public String timeToString(LocalDateTime date) {
		DateTimeFormatter formatter= DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
		return date.format(formatter);
	}

}
