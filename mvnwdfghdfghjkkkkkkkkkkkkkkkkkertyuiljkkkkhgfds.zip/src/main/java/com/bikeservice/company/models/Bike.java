package com.bikeservice.company.models;

import java.sql.Timestamp;
import java.util.Date;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToOne;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Builder
public class Bike {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int bikeId;
	private String bikeMake;
	private String bikeModelName;
	private String bikeRegistrationNumber;
	private int bikeChassisNumber;
	private String bikeKnownIssues;
	private int bikeServiceCost;
	private Timestamp bikeGivenDate;
	private Date bikeExpectedDeliveryDate;
	private Timestamp bikeCreatedDate;
	private Timestamp bikeUpdatedDate;
	@OneToOne(mappedBy = "bike",fetch = FetchType.LAZY,cascade = CascadeType.ALL,orphanRemoval = true)
	private Address address;
	private long phoneNumber;

}
