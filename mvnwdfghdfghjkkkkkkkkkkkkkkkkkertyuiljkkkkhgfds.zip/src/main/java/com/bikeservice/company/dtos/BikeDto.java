package com.bikeservice.company.dtos;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class BikeDto {
	private String bikeMake;
	private String bikeModelName;
	private String bikeRegistrationNumber;
	private int bikeChassisNumber;
	private String bikeKnownIssues;
	private AddressDto address;
	private long phoneNumber;
}
