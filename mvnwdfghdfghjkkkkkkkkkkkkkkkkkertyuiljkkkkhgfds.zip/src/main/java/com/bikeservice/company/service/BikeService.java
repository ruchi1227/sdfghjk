package com.bikeservice.company.service;

import com.bikeservice.company.dtos.BikeDto;
import com.bikeservice.company.models.Bike;

public interface BikeService {
	public Bike createBike(BikeDto bikeDto);
	
}
