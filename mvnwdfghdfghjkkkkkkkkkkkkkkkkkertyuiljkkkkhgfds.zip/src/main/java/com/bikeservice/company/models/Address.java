package com.bikeservice.company.models;

import com.fasterxml.jackson.annotation.JsonIgnore;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Builder
public class Address {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int addressId;
	private int houseNumber;
	private String streetName;
	private String landmark;
	private String city;
	private String state;
	private long pincode;
	@JsonIgnore
	@OneToOne(targetEntity = Bike.class)
	@JoinColumn(name= "bike_id")
	private Bike bike;
	
}
