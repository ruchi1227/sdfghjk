package com.bikeservice.company.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.bikeservice.company.models.Address;

public interface AddressRepo extends JpaRepository<Address, Integer>{

}
